<?php

extract(
	shortcode_atts(
		array(
			'wrapper'   => 'container',
			'className' => '',
		),
		$atts
	)
);
echo '<div class="section' . ( $className ? ' ' . esc_attr( $className ) : '' ) . '"><div class="' . esc_attr( $wrapper ) . '">' . $content . '</div></div>';
